# Games X1

Plataforma de jogos de habilidade **1v1** inspirada no gamesx1.com, pronta para rodar em
**Netlify** (front-end) e **Supabase** (auth, banco, tempo real e regras de negócio).

Inclui: cadastro/login, carteira com depósito/saque, apostas com _escrow_ no servidor,
partidas 1v1 em tempo real (Jogo da Velha), ranking, amigos, programa de afiliados e suporte.

## Stack

- **React 18 + Vite + TypeScript** (SPA)
- **Supabase**: Postgres, Auth (e-mail/senha), Row Level Security, Realtime e funções RPC
- **Netlify**: hospedagem do front com build e redirects SPA

## Estrutura

```
.
├── index.html
├── netlify.toml            # build + redirects SPA + headers
├── public/_redirects       # fallback SPA
├── supabase/schema.sql     # tabelas, RLS, RPCs, realtime (rode no Supabase)
└── src
    ├── components/         # Layout, Avatar, ProtectedRoute
    ├── context/            # AuthContext, WalletContext
    ├── games/registry.ts   # catálogo de jogos
    ├── lib/                # supabase client, formatação
    └── pages/              # Home, Login, Register, Wallet, Ranking, Friends,
                            # Affiliates, Profile, Support, GamePage (Jogo da Velha)
```

## 1. Configurar o Supabase

1. Crie um projeto em https://supabase.com.
2. Abra **SQL Editor** e rode todo o conteúdo de `supabase/schema.sql`.
   Isso cria tabelas, políticas de segurança, funções de aposta e habilita o Realtime.
3. Em **Project Settings > API**, copie a **Project URL** e a **anon public key**.
4. (Opcional, para testes mais rápidos) Em **Authentication > Providers > Email**,
   desligue "Confirm email" para entrar sem confirmar e-mail.

Variáveis de ambiente (crie um arquivo `.env` na raiz):

```env
VITE_SUPABASE_URL=https://SEU-PROJETO.supabase.co
VITE_SUPABASE_ANON_KEY=sua-anon-key-publica
```

> A `anon key` é pública e protegida pelas políticas de RLS. Nunca coloque a
> `service_role` key no front-end.

## 2. Rodar localmente

```bash
npm install
npm run dev
```

Acesse http://localhost:5173.

## 3. Publicar no Netlify

1. Suba o repositório para o GitHub/GitLab.
2. No Netlify, clique em **Add new site > Import an existing project** e escolha o repo.
3. O `netlify.toml` já define:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. Em **Site configuration > Environment variables**, adicione:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. Deploy. As rotas SPA são redirecionadas para `index.html` automaticamente.

## 4. Tornar um usuário administrador

Necessário para aprovar saques (`settle_withdrawal`). No SQL Editor:

```sql
update public.profiles set is_admin = true where username = 'seu_usuario';
```

## Regras de negócio implementadas

- **Bônus de boas-vindas**: R$ 100,00 ao criar conta.
- **Escrow**: ao criar/entrar numa mesa, a aposta sai do saldo e fica retida
  (`locked`) até o fim da partida, tudo dentro de transações no Postgres.
- **Rake**: o vencedor recebe o pote menos 10% de taxa.
- **Empate**: devolve a aposta dos dois jogadores.
- **Ranking**: vitórias, derrotas, aproveitamento e ganhos por jogador.
- **Afiliados**: 5% de comissão sobre cada depósito dos indicados.

## Segurança

- Toda escrita em saldo/partidas passa por **funções RPC `security definer`** com
  validação de turno, saldo e propriedade — o cliente não altera saldo direto.
- **RLS** habilitado em todas as tabelas: cada usuário só lê o que é seu.
- `make_move` valida a jogada e resolve vitória/empate no servidor (anti-trapaça).

## Pagamentos (importante)

O gateway é **simulado** para demonstração: `create_deposit` cria o depósito e
`pay_deposit` confirma e credita na hora. Para produção, **não** permita que o
cliente confirme o próprio depósito: marque o depósito como `paid` apenas a partir
de um **webhook assinado** do provedor (Pix, cripto ou cartão), usando a
`service_role` key em uma Edge Function do Supabase.

## Próximos jogos

O catálogo tem 9 títulos. Apenas o **Jogo da Velha** está jogável; os demais aparecem
como "Em breve". Para ativar um novo jogo, implemente a regra no `supabase` (RPCs
`create_match`/`make_move` específicas ou uma tabela de estado genérica) e a UI na
`GamePage`, reutilizando o padrão de lobby e tempo real já existente.
