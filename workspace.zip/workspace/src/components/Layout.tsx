import { useState } from 'react'
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useWallet } from '../context/WalletContext'
import { isSupabaseConfigured } from '../lib/supabase'
import { brl } from '../lib/format'
import { Avatar } from './Avatar'

const NAV = [
  { to: '/', label: 'Início', end: true },
  { to: '/ranking', label: 'Ranking' },
  { to: '/amigos', label: 'Amigos' },
  { to: '/afiliados', label: 'Afiliados' },
  { to: '/suporte', label: 'Suporte' }
]

export function Layout() {
  const { user, profile, signOut } = useAuth()
  const { balance } = useWallet()
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)

  async function handleSignOut() {
    await signOut()
    navigate('/')
  }

  return (
    <div className="app-shell">
      {!isSupabaseConfigured && (
        <div className="setup-banner">
          Modo demonstração: configure <code>VITE_SUPABASE_URL</code> e{' '}
          <code>VITE_SUPABASE_ANON_KEY</code> no arquivo <code>.env</code> para ativar
          login, carteira e partidas.
        </div>
      )}

      <header className="site-header">
        <div className="container header-inner">
          <Link to="/" className="brand" onClick={() => setMenuOpen(false)}>
            <span className="brand-mark">X1</span>
            <span className="brand-name">Games X1</span>
          </Link>

          <nav className={`main-nav ${menuOpen ? 'open' : ''}`}>
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={() => setMenuOpen(false)}
                className={({ isActive }) => (isActive ? 'active' : undefined)}
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="header-actions">
            {user ? (
              <>
                <Link to="/carteira" className="balance-chip" title="Sua carteira">
                  <span className="balance-label">Saldo</span>
                  <strong>{brl(balance)}</strong>
                </Link>
                <Link to="/perfil" className="user-chip">
                  <Avatar name={profile?.display_name || profile?.username} src={profile?.avatar_url} size={30} />
                  <span className="user-chip-name">
                    {profile?.display_name || profile?.username || 'Perfil'}
                  </span>
                </Link>
                <button className="btn btn-ghost btn-sm" onClick={handleSignOut}>
                  Sair
                </button>
              </>
            ) : (
              <>
                <Link to="/entrar" className="btn btn-ghost btn-sm">
                  Entrar
                </Link>
                <Link to="/cadastrar" className="btn btn-primary btn-sm">
                  Criar conta
                </Link>
              </>
            )}
            <button
              className="menu-toggle"
              aria-label="Abrir menu"
              onClick={() => setMenuOpen((v) => !v)}
            >
              ☰
            </button>
          </div>
        </div>
      </header>

      <main className="site-main">
        <Outlet />
      </main>

      <footer className="site-footer">
        <div className="container footer-inner">
          <div>
            <strong>Games X1</strong>
            <p>Jogos de habilidade 1v1. Jogue com responsabilidade.</p>
          </div>
          <div className="footer-links">
            <Link to="/ranking">Ranking</Link>
            <Link to="/afiliados">Afiliados</Link>
            <Link to="/suporte">Suporte</Link>
          </div>
          <p className="footer-note">
            Plataforma demonstrativa. Nenhuma transação financeira real é processada.
          </p>
        </div>
      </footer>
    </div>
  )
}
