import { initials } from '../lib/format'

interface AvatarProps {
  name: string | null | undefined
  src?: string | null
  size?: number
}

export function Avatar({ name, src, size = 40 }: AvatarProps) {
  const style = { width: size, height: size, fontSize: size * 0.4 }
  if (src) {
    return <img className="avatar" style={style} src={src} alt={name ?? 'Avatar'} />
  }
  return (
    <span className="avatar avatar-fallback" style={style} aria-hidden="true">
      {initials(name)}
    </span>
  )
}
