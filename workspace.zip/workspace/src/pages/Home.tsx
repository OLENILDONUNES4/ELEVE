import { Link } from 'react-router-dom'
import { GAMES } from '../games/registry'
import { useAuth } from '../context/AuthContext'

const HIGHLIGHTS = [
  { title: 'Partidas 1v1', text: 'Desafie outro jogador em tempo real e mostre quem manda.' },
  { title: 'Carteira integrada', text: 'Deposite via Pix, cripto ou cartão e saque quando quiser.' },
  { title: 'Ranking e afiliados', text: 'Suba no ranking e ganhe comissão indicando amigos.' }
]

export function Home() {
  const { user } = useAuth()

  return (
    <div className="container page">
      <section className="hero">
        <div className="hero-copy">
          <span className="pill">Jogos de habilidade 1v1</span>
          <h1>
            O duelo é você <span className="accent">contra o mundo</span>.
          </h1>
          <p>
            Truco, dominó, sinuca, xadrez e muito mais. Escolha seu jogo, defina a aposta e
            entre na mesa. O vencedor leva.
          </p>
          <div className="hero-actions">
            {user ? (
              <a href="#jogos" className="btn btn-primary btn-lg">
                Escolher jogo
              </a>
            ) : (
              <>
                <Link to="/cadastrar" className="btn btn-primary btn-lg">
                  Criar conta grátis
                </Link>
                <Link to="/entrar" className="btn btn-ghost btn-lg">
                  Já tenho conta
                </Link>
              </>
            )}
          </div>
          <ul className="hero-stats">
            <li>
              <strong>9</strong>
              <span>jogos</span>
            </li>
            <li>
              <strong>24h</strong>
              <span>saques</span>
            </li>
            <li>
              <strong>R$ 100</strong>
              <span>de bônus</span>
            </li>
          </ul>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="orb orb-1" />
          <div className="orb orb-2" />
          <div className="hero-card">
            <div className="hero-card-top">
              <span>Mesa 1v1</span>
              <span className="live-dot">ao vivo</span>
            </div>
            <div className="hero-vs">
              <div className="vs-player">
                <span className="vs-avatar">A</span>
                <span>Você</span>
              </div>
              <span className="vs-badge">VS</span>
              <div className="vs-player">
                <span className="vs-avatar alt">B</span>
                <span>Rival</span>
              </div>
            </div>
            <div className="hero-pot">Pote: R$ 50,00</div>
          </div>
        </div>
      </section>

      <section className="highlights">
        {HIGHLIGHTS.map((h) => (
          <div key={h.title} className="highlight-card">
            <h3>{h.title}</h3>
            <p>{h.text}</p>
          </div>
        ))}
      </section>

      <section id="jogos" className="section">
        <div className="section-head">
          <h2>Escolha seu jogo</h2>
          <p>Partidas ranqueadas 1v1 com aposta combinada entre os jogadores.</p>
        </div>
        <div className="game-grid">
          {GAMES.map((game) => (
            <Link
              key={game.slug}
              to={`/jogo/${game.slug}`}
              className={`game-card ${game.available ? '' : 'soon'}`}
            >
              <span className="game-icon">{game.icon}</span>
              <div className="game-body">
                <h3>{game.name}</h3>
                <p>{game.description}</p>
              </div>
              <span className={`game-tag ${game.available ? 'on' : ''}`}>
                {game.available ? 'Jogar agora' : 'Em breve'}
              </span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}
