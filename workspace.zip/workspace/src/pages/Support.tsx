import { useCallback, useEffect, useState, type FormEvent } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { errorMessage, shortDate } from '../lib/format'
import type { SupportMessage, SupportTicket } from '../types'

const CATEGORIES = ['geral', 'pagamento', 'conta', 'jogo', 'afiliados']

export function Support() {
  const { user } = useAuth()
  const [tickets, setTickets] = useState<SupportTicket[]>([])
  const [selected, setSelected] = useState<SupportTicket | null>(null)
  const [messages, setMessages] = useState<SupportMessage[]>([])
  const [subject, setSubject] = useState('')
  const [category, setCategory] = useState('geral')
  const [body, setBody] = useState('')
  const [reply, setReply] = useState('')
  const [feedback, setFeedback] = useState<{ kind: 'error' | 'info'; text: string } | null>(null)
  const [busy, setBusy] = useState(false)

  const loadTickets = useCallback(async () => {
    if (!user) return
    const { data } = await supabase
      .from('support_tickets')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
    setTickets((data as SupportTicket[]) ?? [])
  }, [user])

  useEffect(() => {
    loadTickets()
  }, [loadTickets])

  async function openTicket(ticket: SupportTicket) {
    setSelected(ticket)
    const { data } = await supabase
      .from('support_messages')
      .select('*')
      .eq('ticket_id', ticket.id)
      .order('created_at', { ascending: true })
    setMessages((data as SupportMessage[]) ?? [])
  }

  async function createTicket(e: FormEvent) {
    e.preventDefault()
    if (!user) return
    setFeedback(null)
    if (subject.trim().length < 3 || body.trim().length < 3) {
      setFeedback({ kind: 'error', text: 'Preencha assunto e mensagem.' })
      return
    }
    setBusy(true)
    try {
      const { data, error } = await supabase
        .from('support_tickets')
        .insert({ user_id: user.id, subject: subject.trim(), category })
        .select('*')
        .single()
      if (error) throw error
      const ticket = data as SupportTicket
      const { error: msgError } = await supabase
        .from('support_messages')
        .insert({ ticket_id: ticket.id, author_id: user.id, is_staff: false, body: body.trim() })
      if (msgError) throw msgError
      setSubject('')
      setBody('')
      await loadTickets()
      await openTicket(ticket)
    } catch (err) {
      setFeedback({ kind: 'error', text: errorMessage(err) })
    } finally {
      setBusy(false)
    }
  }

  async function sendReply(e: FormEvent) {
    e.preventDefault()
    if (!user || !selected || reply.trim().length < 1) return
    setBusy(true)
    const { error } = await supabase
      .from('support_messages')
      .insert({ ticket_id: selected.id, author_id: user.id, is_staff: false, body: reply.trim() })
    setBusy(false)
    if (error) {
      setFeedback({ kind: 'error', text: errorMessage(error) })
      return
    }
    setReply('')
    await openTicket(selected)
  }

  if (selected) {
    return (
      <div className="container page">
        <header className="page-head">
          <button className="back-link" onClick={() => setSelected(null)}>
            ← Meus tickets
          </button>
          <h1>{selected.subject}</h1>
          <p className="muted small">
            {selected.category} · <span className={`status status-${selected.status}`}>{selected.status}</span>
          </p>
        </header>

        <section className="card">
          <ul className="chat">
            {messages.map((m) => (
              <li key={m.id} className={`chat-msg ${m.is_staff ? 'staff' : 'me'}`}>
                <div className="chat-bubble">
                  <p>{m.body}</p>
                  <span className="muted small">
                    {m.is_staff ? 'Suporte' : 'Você'} · {shortDate(m.created_at)}
                  </span>
                </div>
              </li>
            ))}
            {messages.length === 0 && <div className="empty">Sem mensagens.</div>}
          </ul>

          <form onSubmit={sendReply} className="chat-form">
            <input
              value={reply}
              onChange={(e) => setReply(e.target.value)}
              placeholder="Escreva uma mensagem…"
            />
            <button className="btn btn-primary" disabled={busy}>
              Enviar
            </button>
          </form>
        </section>
      </div>
    )
  }

  return (
    <div className="container page">
      <header className="page-head">
        <h1>Suporte</h1>
        <p className="muted">Abra um ticket e nossa equipe responderá o mais rápido possível.</p>
      </header>

      <div className="two-col">
        <section className="card">
          <h2>Novo ticket</h2>
          <form onSubmit={createTicket} className="stack">
            <label className="field">
              <span>Assunto</span>
              <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Resuma o problema" />
            </label>
            <label className="field">
              <span>Categoria</span>
              <select value={category} onChange={(e) => setCategory(e.target.value)}>
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </label>
            <label className="field">
              <span>Mensagem</span>
              <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={5} placeholder="Descreva com detalhes" />
            </label>
            {feedback && (
              <div className={`alert alert-${feedback.kind === 'error' ? 'error' : 'info'}`}>
                {feedback.text}
              </div>
            )}
            <button className="btn btn-primary" disabled={busy}>
              Abrir ticket
            </button>
          </form>
        </section>

        <section className="card">
          <h2>Meus tickets</h2>
          {tickets.length === 0 ? (
            <div className="empty">Nenhum ticket aberto.</div>
          ) : (
            <ul className="match-list">
              {tickets.map((t) => (
                <li key={t.id} className="match-row clickable" onClick={() => openTicket(t)}>
                  <div>
                    <strong>{t.subject}</strong>
                    <span className="muted small">
                      {t.category} · {shortDate(t.created_at)}
                    </span>
                  </div>
                  <span className={`status status-${t.status}`}>{t.status}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}
