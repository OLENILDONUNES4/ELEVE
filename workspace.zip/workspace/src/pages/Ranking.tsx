import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { brl } from '../lib/format'
import { Avatar } from '../components/Avatar'
import type { RankRow } from '../types'

export function Ranking() {
  const { user } = useAuth()
  const [rows, setRows] = useState<RankRow[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase
      .from('ranking')
      .select('*')
      .order('wins', { ascending: false })
      .order('earnings', { ascending: false })
      .limit(100)
      .then(({ data }) => {
        setRows((data as RankRow[]) ?? [])
        setLoading(false)
      })
  }, [])

  return (
    <div className="container page">
      <header className="page-head">
        <h1>Ranking</h1>
        <p className="muted">Os jogadores mais vencedores da plataforma.</p>
      </header>

      {loading ? (
        <div className="loading-block">Carregando…</div>
      ) : rows.length === 0 ? (
        <div className="empty">Nenhuma partida disputada ainda. Seja o primeiro!</div>
      ) : (
        <div className="table-wrap card">
          <table className="rank-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Jogador</th>
                <th>Partidas</th>
                <th>V</th>
                <th>D</th>
                <th>Aproveitamento</th>
                <th>Ganhos</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const rate = r.matches > 0 ? Math.round((r.wins / r.matches) * 100) : 0
                const me = r.id === user?.id
                return (
                  <tr key={r.id} className={me ? 'me' : ''}>
                    <td className={`pos pos-${i + 1}`}>{i + 1}</td>
                    <td>
                      <div className="rank-player">
                        <Avatar name={r.display_name || r.username} src={r.avatar_url} size={32} />
                        <span>
                          {r.display_name || r.username}
                          {me && <em className="you-tag">você</em>}
                        </span>
                      </div>
                    </td>
                    <td>{r.matches}</td>
                    <td className="win">{r.wins}</td>
                    <td className="loss">{r.losses}</td>
                    <td>{rate}%</td>
                    <td className="earn">{brl(r.earnings)}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
