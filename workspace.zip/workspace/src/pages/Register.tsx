import { useState, type FormEvent } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { errorMessage } from '../lib/format'

export function Register() {
  const { signUp } = useAuth()
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const referral = params.get('ref')

  const [username, setUsername] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [info, setInfo] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setInfo(null)

    if (username.trim().length < 3) {
      setError('O nome de usuário deve ter pelo menos 3 caracteres.')
      return
    }
    if (password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres.')
      return
    }

    setLoading(true)
    try {
      const { needsConfirmation } = await signUp({
        email: email.trim(),
        password,
        username: username.trim(),
        displayName: displayName.trim() || undefined,
        referredBy: referral
      })
      if (needsConfirmation) {
        setInfo('Conta criada! Confirme o e-mail que enviamos para ativar seu acesso.')
      } else {
        navigate('/', { replace: true })
      }
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container page auth-page">
      <div className="auth-card">
        <h1>Criar conta</h1>
        <p className="muted">Comece com R$ 100 de bônus para testar as mesas.</p>
        {referral && <div className="alert alert-info">Você foi indicado por um amigo.</div>}
        <form onSubmit={handleSubmit} className="stack">
          <label className="field">
            <span>Nome de usuário</span>
            <input
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="seu_apelido"
              autoComplete="username"
            />
          </label>
          <label className="field">
            <span>Nome de exibição</span>
            <input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Como quer ser chamado"
            />
          </label>
          <label className="field">
            <span>E-mail</span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="voce@email.com"
              autoComplete="email"
            />
          </label>
          <label className="field">
            <span>Senha</span>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="mínimo 6 caracteres"
              autoComplete="new-password"
            />
          </label>
          {error && <div className="alert alert-error">{error}</div>}
          {info && <div className="alert alert-info">{info}</div>}
          <button className="btn btn-primary btn-block" disabled={loading}>
            {loading ? 'Criando…' : 'Criar conta'}
          </button>
        </form>
        <p className="auth-switch">
          Já tem conta? <Link to="/entrar">Entrar</Link>
        </p>
      </div>
    </div>
  )
}
