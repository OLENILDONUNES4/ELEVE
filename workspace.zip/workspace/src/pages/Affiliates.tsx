import { useCallback, useEffect, useMemo, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { brl, shortDate, toNumber } from '../lib/format'
import { Avatar } from '../components/Avatar'
import type { AffiliateEarning, Profile } from '../types'

export function Affiliates() {
  const { user } = useAuth()
  const [earnings, setEarnings] = useState<AffiliateEarning[]>([])
  const [referred, setReferred] = useState<Profile[]>([])
  const [copied, setCopied] = useState(false)
  const [loading, setLoading] = useState(true)

  const link = useMemo(
    () => (user ? `${window.location.origin}/cadastrar?ref=${user.id}` : ''),
    [user]
  )

  const load = useCallback(async () => {
    if (!user) return
    const [earn, refs] = await Promise.all([
      supabase
        .from('affiliate_earnings')
        .select('*')
        .eq('affiliate_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50),
      supabase.from('profiles').select('*').eq('referred_by', user.id)
    ])
    setEarnings((earn.data as AffiliateEarning[]) ?? [])
    setReferred((refs.data as Profile[]) ?? [])
    setLoading(false)
  }, [user])

  useEffect(() => {
    load()
  }, [load])

  const totalCommission = earnings.reduce((sum, e) => sum + toNumber(e.amount), 0)

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(link)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      setCopied(false)
    }
  }

  return (
    <div className="container page">
      <header className="page-head">
        <h1>Programa de Afiliados</h1>
        <p className="muted">
          Convide amigos e ganhe <strong>5%</strong> de comissão sobre cada depósito deles.
        </p>
      </header>

      <div className="wallet-cards">
        <div className="wallet-card primary">
          <span>Comissão acumulada</span>
          <strong>{brl(totalCommission)}</strong>
        </div>
        <div className="wallet-card">
          <span>Indicados</span>
          <strong>{referred.length}</strong>
        </div>
        <div className="wallet-card">
          <span>Seu código</span>
          <strong className="mono">{user ? user.id.slice(0, 8) : '-'}</strong>
        </div>
      </div>

      <section className="card">
        <h2>Seu link de indicação</h2>
        <p className="muted small">Compartilhe com amigos. A comissão aparece na sua carteira.</p>
        <div className="copy-row">
          <input readOnly value={link} onFocus={(e) => e.currentTarget.select()} />
          <button className="btn btn-primary" onClick={copyLink}>
            {copied ? 'Copiado!' : 'Copiar'}
          </button>
        </div>
      </section>

      <div className="two-col">
        <section className="card">
          <h2>Indicados ({referred.length})</h2>
          {loading ? (
            <div className="loading-block">Carregando…</div>
          ) : referred.length === 0 ? (
            <div className="empty">Nenhum indicado ainda. Comece a divulgar!</div>
          ) : (
            <ul className="match-list">
              {referred.map((p) => (
                <li key={p.id} className="match-row">
                  <div className="match-player">
                    <Avatar name={p.display_name || p.username} src={p.avatar_url} size={34} />
                    <div>
                      <strong>{p.display_name || p.username}</strong>
                      <span className="muted small">Entrou em {shortDate(p.created_at)}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card">
          <h2>Comissões</h2>
          {earnings.length === 0 ? (
            <div className="empty">Sem comissões registradas.</div>
          ) : (
            <ul className="tx-list">
              {earnings.map((e) => (
                <li key={e.id} className="tx-item">
                  <div>
                    <strong>Comissão</strong>
                    <span className="muted small">{shortDate(e.created_at)}</span>
                  </div>
                  <span className="tx-amount pos">+{brl(e.amount)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}
