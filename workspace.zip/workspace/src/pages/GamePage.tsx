import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { useWallet } from '../context/WalletContext'
import { getGame } from '../games/registry'
import { brl, errorMessage, toNumber } from '../lib/format'
import { Avatar } from '../components/Avatar'
import type { Match, Profile } from '../types'

const STAKES = [0, 5, 10, 25, 50, 100]

export function GamePage() {
  const { slug } = useParams()
  const game = getGame(slug)

  if (!game) {
    return (
      <div className="container page">
        <div className="empty-state">
          <h1>Jogo não encontrado</h1>
          <Link to="/" className="btn btn-primary">
            Voltar para o início
          </Link>
        </div>
      </div>
    )
  }

  if (!game.available) {
    return (
      <div className="container page">
        <div className="soon-state">
          <span className="game-icon big">{game.icon}</span>
          <span className="pill">Em breve</span>
          <h1>{game.name}</h1>
          <p className="muted">{game.description}</p>
          <p className="muted">
            Estamos finalizando este título. Enquanto isso, jogue o Jogo da Velha X1 ou
            explore as outras mesas.
          </p>
          <div className="hero-actions">
            <Link to="/jogo/jogodavelha" className="btn btn-primary">
              Jogar Jogo da Velha
            </Link>
            <Link to="/" className="btn btn-ghost">
              Ver todos os jogos
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return <TicTacToeTable />
}

function TicTacToeTable() {
  const { user, profile } = useAuth()
  const { balance, refresh } = useWallet()

  const [openMatches, setOpenMatches] = useState<Match[]>([])
  const [activeMatch, setActiveMatch] = useState<Match | null>(null)
  const [players, setPlayers] = useState<Record<string, Profile>>({})
  const [stake, setStake] = useState(10)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const activeId = activeMatch?.id
  const chanRef = useRef<ReturnType<typeof supabase.channel> | null>(null)

  const loadOpen = useCallback(async () => {
    const { data } = await supabase
      .from('matches')
      .select('*')
      .eq('game_slug', 'jogodavelha')
      .eq('status', 'waiting')
      .order('created_at', { ascending: true })
      .limit(30)
    setOpenMatches((data as Match[]) ?? [])
    setLoading(false)
  }, [])

  const loadMyActive = useCallback(async () => {
    if (!user) return
    const { data } = await supabase
      .from('matches')
      .select('*')
      .eq('game_slug', 'jogodavelha')
      .in('status', ['waiting', 'active'])
      .or(`player_x.eq.${user.id},player_o.eq.${user.id}`)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()
    if (data) setActiveMatch(data as Match)
  }, [user])

  const loadPlayers = useCallback(async (ids: string[]) => {
    const unique = Array.from(new Set(ids)).filter(Boolean)
    if (unique.length === 0) return
    const { data } = await supabase.from('profiles').select('*').in('id', unique)
    if (data) {
      const map: Record<string, Profile> = {}
      ;(data as Profile[]).forEach((p) => (map[p.id] = p))
      setPlayers((prev) => ({ ...prev, ...map }))
    }
  }, [])

  // Carga inicial + lobby em tempo real
  useEffect(() => {
    loadOpen()
    loadMyActive()
    const channel = supabase
      .channel('lobby:jogodavelha')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'matches', filter: 'game_slug=eq.jogodavelha' },
        () => {
          loadOpen()
        }
      )
      .subscribe()
    return () => {
      supabase.removeChannel(channel)
    }
  }, [loadOpen, loadMyActive])

  // Assina a partida ativa
  useEffect(() => {
    if (chanRef.current) {
      supabase.removeChannel(chanRef.current)
      chanRef.current = null
    }
    if (!activeId) return
    const channel = supabase
      .channel(`match:${activeId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'matches', filter: `id=eq.${activeId}` },
        (payload) => setActiveMatch(payload.new as Match)
      )
      .subscribe()
    chanRef.current = channel
    return () => {
      supabase.removeChannel(channel)
    }
  }, [activeId])

  // Resolve nomes dos jogadores
  useEffect(() => {
    const ids: string[] = []
    openMatches.forEach((m) => {
      ids.push(m.player_x)
      if (m.player_o) ids.push(m.player_o)
    })
    if (activeMatch) {
      ids.push(activeMatch.player_x)
      if (activeMatch.player_o) ids.push(activeMatch.player_o)
    }
    loadPlayers(ids)
  }, [openMatches, activeMatch, loadPlayers])

  // Recarrega carteira quando a partida termina
  useEffect(() => {
    if (activeMatch?.status === 'finished') refresh()
  }, [activeMatch?.status, refresh])

  async function createMatch() {
    setError(null)
    setBusy(true)
    try {
      const { data, error: rpcError } = await supabase.rpc('create_match', {
        p_game_slug: 'jogodavelha',
        p_stake: stake
      })
      if (rpcError) throw rpcError
      await refresh()
      const { data: row } = await supabase.from('matches').select('*').eq('id', data).single()
      if (row) setActiveMatch(row as Match)
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  async function joinMatch(match: Match) {
    setError(null)
    setBusy(true)
    try {
      const { error: rpcError } = await supabase.rpc('join_match', { p_match_id: match.id })
      if (rpcError) throw rpcError
      await refresh()
      const { data: row } = await supabase.from('matches').select('*').eq('id', match.id).single()
      if (row) setActiveMatch(row as Match)
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  async function cancelMatch() {
    if (!activeMatch) return
    setBusy(true)
    try {
      const { error: rpcError } = await supabase.rpc('cancel_match', { p_match_id: activeMatch.id })
      if (rpcError) throw rpcError
      await refresh()
      setActiveMatch(null)
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  async function play(index: number) {
    if (!activeMatch) return
    setError(null)
    const { data, error: rpcError } = await supabase.rpc('make_move', {
      p_match_id: activeMatch.id,
      p_index: index
    })
    if (rpcError) {
      setError(errorMessage(rpcError))
      return
    }
    const updated = data as unknown as Match
    setActiveMatch(updated)
    if (updated?.status === 'finished') refresh()
  }

  if (activeMatch) {
    return (
      <MatchRoom
        match={activeMatch}
        players={players}
        meId={user?.id ?? ''}
        myName={profile?.display_name || profile?.username || 'Você'}
        busy={busy}
        error={error}
        onPlay={play}
        onCancel={cancelMatch}
        onLeave={() => setActiveMatch(null)}
      />
    )
  }

  const openOthers = openMatches.filter((m) => m.player_x !== user?.id)

  return (
    <div className="container page">
      <header className="page-head">
        <Link to="/" className="back-link">
          ← Todos os jogos
        </Link>
        <h1>Jogo da Velha X1</h1>
        <p className="muted">
          Crie uma mesa com aposta ou entre em uma mesa aberta. Saldo: <strong>{brl(balance)}</strong>
        </p>
      </header>

      <div className="two-col">
        <section className="card">
          <h2>Criar mesa</h2>
          <div className="field">
            <span>Valor da aposta</span>
            <div className="chip-row">
              {STAKES.map((s) => (
                <button
                  key={s}
                  className={`chip ${stake === s ? 'active' : ''}`}
                  onClick={() => setStake(s)}
                >
                  {s === 0 ? 'Amistoso' : brl(s)}
                </button>
              ))}
            </div>
          </div>
          <p className="muted small">
            Você só paga a aposta e o valor fica retido até o fim da partida. O vencedor leva o
            pote (taxa de 10%). Empate devolve as apostas.
          </p>
          {error && <div className="alert alert-error">{error}</div>}
          <button className="btn btn-primary btn-block" disabled={busy} onClick={createMatch}>
            {busy ? 'Criando…' : 'Criar mesa'}
          </button>
        </section>

        <section className="card">
          <h2>Mesas abertas</h2>
          {loading ? (
            <div className="loading-block">Carregando…</div>
          ) : openOthers.length === 0 ? (
            <div className="empty">Nenhuma mesa aberta. Crie a sua!</div>
          ) : (
            <ul className="match-list">
              {openOthers.map((m) => {
                const host = players[m.player_x]
                return (
                  <li key={m.id} className="match-row">
                    <div className="match-player">
                      <Avatar name={host?.display_name || host?.username} src={host?.avatar_url} size={34} />
                      <div>
                        <strong>{host?.display_name || host?.username || 'Jogador'}</strong>
                        <span className="muted small">Aposta {toNumber(m.stake) > 0 ? brl(m.stake) : 'Amistoso'}</span>
                      </div>
                    </div>
                    <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => joinMatch(m)}>
                      Entrar
                    </button>
                  </li>
                )
              })}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}

interface RoomProps {
  match: Match
  players: Record<string, Profile>
  meId: string
  myName: string
  busy: boolean
  error: string | null
  onPlay: (index: number) => void
  onCancel: () => void
  onLeave: () => void
}

function MatchRoom({ match, players, meId, myName, busy, error, onPlay, onCancel, onLeave }: RoomProps) {
  const isX = match.player_x === meId
  const myMark = isX ? 'X' : 'O'
  const opponentId = isX ? match.player_o : match.player_x
  const opponent = opponentId ? players[opponentId] : undefined
  const opponentName = opponent?.display_name || opponent?.username || 'Aguardando…'

  const finished = match.status === 'finished'
  const waiting = match.status === 'waiting'
  const isMyTurn = !finished && !waiting && match.turn === myMark

  const outcome = useMemo(() => {
    if (!finished) return null
    if (match.result === 'draw') return { text: 'Empate!', tone: 'draw' as const }
    return match.winner === meId
      ? { text: 'Você venceu!', tone: 'win' as const }
      : { text: 'Você perdeu.', tone: 'loss' as const }
  }, [finished, match.result, match.winner, meId])

  const pot = toNumber(match.pot)

  return (
    <div className="container page">
      <header className="page-head center">
        <span className="pill">{toNumber(match.stake) > 0 ? `Aposta ${brl(match.stake)}` : 'Amistoso'}</span>
        <h1>
          {myName} <span className="accent">vs</span> {opponentName}
        </h1>
        {pot > 0 && !finished && <p className="muted">Pote em jogo: {brl(pot)}</p>}
      </header>

      <div className="board-wrap">
        <div className="board-players">
          <div className={`board-player ${match.turn === 'X' ? 'turn' : ''}`}>
            <Avatar
              name={isX ? myName : players[match.player_x]?.display_name || players[match.player_x]?.username}
              size={40}
            />
            <div>
              <strong>{isX ? myName : players[match.player_x]?.username || 'Jogador X'}</strong>
              <span className="muted small">X</span>
            </div>
          </div>
          <span className="vs-badge">VS</span>
          <div className={`board-player ${match.turn === 'O' ? 'turn' : ''}`}>
            <Avatar
              name={isX ? opponentName : myName}
              size={40}
            />
            <div>
              <strong>{isX ? opponentName : myName}</strong>
              <span className="muted small">O</span>
            </div>
          </div>
        </div>

        <div className="board">
          {match.board.map((cell, i) => {
            const playable = isMyTurn && cell === ''
            return (
              <button
                key={i}
                className={`cell ${cell ? 'filled' : ''} ${cell === 'X' ? 'x' : cell === 'O' ? 'o' : ''}`}
                disabled={!playable || busy}
                onClick={() => onPlay(i)}
              >
                {cell}
              </button>
            )
          })}
        </div>

        {waiting && (
          <div className="alert alert-info board-status">
            Aguardando um oponente entrar na mesa…
          </div>
        )}
        {!finished && !waiting && (
          <div className={`board-status ${isMyTurn ? 'my-turn' : ''}`}>
            {isMyTurn ? 'Sua vez' : `Vez de ${opponentName}`}
          </div>
        )}
        {outcome && (
          <div className={`board-status outcome ${outcome.tone}`}>{outcome.text}</div>
        )}
        {error && <div className="alert alert-error board-status">{error}</div>}

        <div className="board-actions">
          {waiting && (
            <button className="btn btn-ghost" disabled={busy} onClick={onCancel}>
              Cancelar mesa
            </button>
          )}
          {finished && (
            <button className="btn btn-primary" onClick={onLeave}>
              Voltar ao lobby
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
