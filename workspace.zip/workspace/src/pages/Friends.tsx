import { useCallback, useEffect, useState, type FormEvent } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { errorMessage } from '../lib/format'
import { Avatar } from '../components/Avatar'
import type { FriendRequest, Friendship, Profile } from '../types'

export function Friends() {
  const { user } = useAuth()
  const [username, setUsername] = useState('')
  const [incoming, setIncoming] = useState<FriendRequest[]>([])
  const [outgoing, setOutgoing] = useState<FriendRequest[]>([])
  const [friends, setFriends] = useState<Profile[]>([])
  const [profiles, setProfiles] = useState<Record<string, Profile>>({})
  const [feedback, setFeedback] = useState<{ kind: 'error' | 'info'; text: string } | null>(null)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    if (!user) return
    const [inc, out, fr] = await Promise.all([
      supabase
        .from('friend_requests')
        .select('*')
        .eq('receiver', user.id)
        .eq('status', 'pending')
        .order('created_at', { ascending: false }),
      supabase
        .from('friend_requests')
        .select('*')
        .eq('sender', user.id)
        .eq('status', 'pending')
        .order('created_at', { ascending: false }),
      supabase
        .from('friendships')
        .select('*')
        .or(`user_a.eq.${user.id},user_b.eq.${user.id}`)
    ])

    const incRows = (inc.data as FriendRequest[]) ?? []
    const outRows = (out.data as FriendRequest[]) ?? []
    const frRows = (fr.data as Friendship[]) ?? []
    setIncoming(incRows)
    setOutgoing(outRows)

    const friendIds = frRows.map((f) => (f.user_a === user.id ? f.user_b : f.user_a))
    const ids = new Set<string>([
      ...friendIds,
      ...incRows.map((r) => r.sender),
      ...outRows.map((r) => r.receiver)
    ])
    if (ids.size > 0) {
      const { data } = await supabase.from('profiles').select('*').in('id', Array.from(ids))
      const map: Record<string, Profile> = {}
      ;(data as Profile[]).forEach((p) => (map[p.id] = p))
      setProfiles(map)
      setFriends(friendIds.map((id) => map[id]).filter(Boolean))
    } else {
      setFriends([])
    }
  }, [user])

  useEffect(() => {
    load()
  }, [load])

  async function addFriend(e: FormEvent) {
    e.preventDefault()
    setFeedback(null)
    if (username.trim().length < 3) return
    setBusy(true)
    try {
      const { error } = await supabase.rpc('send_friend_request', {
        p_username: username.trim().toLowerCase()
      })
      if (error) throw error
      setFeedback({ kind: 'info', text: 'Solicitação enviada!' })
      setUsername('')
      await load()
    } catch (err) {
      setFeedback({ kind: 'error', text: errorMessage(err) })
    } finally {
      setBusy(false)
    }
  }

  async function respond(id: string, accept: boolean) {
    setBusy(true)
    setFeedback(null)
    try {
      const { error } = await supabase.rpc('respond_friend_request', {
        p_request_id: id,
        p_accept: accept
      })
      if (error) throw error
      await load()
    } catch (err) {
      setFeedback({ kind: 'error', text: errorMessage(err) })
    } finally {
      setBusy(false)
    }
  }

  async function removeFriend(id: string) {
    setBusy(true)
    try {
      const { error } = await supabase.rpc('remove_friend', { p_friend_id: id })
      if (error) throw error
      await load()
    } catch (err) {
      setFeedback({ kind: 'error', text: errorMessage(err) })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="container page">
      <header className="page-head">
        <h1>Amigos</h1>
        <p className="muted">Adicione jogadores e combine partidas.</p>
      </header>

      <section className="card">
        <form onSubmit={addFriend} className="inline-form">
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Nome de usuário do jogador"
          />
          <button className="btn btn-primary" disabled={busy}>
            Adicionar
          </button>
        </form>
        {feedback && (
          <div className={`alert alert-${feedback.kind === 'error' ? 'error' : 'info'}`}>
            {feedback.text}
          </div>
        )}
      </section>

      {incoming.length > 0 && (
        <section className="card">
          <h2>Solicitações recebidas</h2>
          <ul className="match-list">
            {incoming.map((r) => {
              const p = profiles[r.sender]
              return (
                <li key={r.id} className="match-row">
                  <div className="match-player">
                    <Avatar name={p?.display_name || p?.username} src={p?.avatar_url} size={34} />
                    <div>
                      <strong>{p?.display_name || p?.username || 'Jogador'}</strong>
                      <span className="muted small">@{p?.username}</span>
                    </div>
                  </div>
                  <div className="row-actions">
                    <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => respond(r.id, true)}>
                      Aceitar
                    </button>
                    <button className="btn btn-ghost btn-sm" disabled={busy} onClick={() => respond(r.id, false)}>
                      Recusar
                    </button>
                  </div>
                </li>
              )
            })}
          </ul>
        </section>
      )}

      <div className="two-col">
        <section className="card">
          <h2>Meus amigos ({friends.length})</h2>
          {friends.length === 0 ? (
            <div className="empty">Você ainda não tem amigos adicionados.</div>
          ) : (
            <ul className="match-list">
              {friends.map((f) => (
                <li key={f.id} className="match-row">
                  <div className="match-player">
                    <Avatar name={f.display_name || f.username} src={f.avatar_url} size={34} />
                    <div>
                      <strong>{f.display_name || f.username}</strong>
                      <span className="muted small">@{f.username}</span>
                    </div>
                  </div>
                  <button className="btn btn-ghost btn-sm" disabled={busy} onClick={() => removeFriend(f.id)}>
                    Remover
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card">
          <h2>Solicitações enviadas</h2>
          {outgoing.length === 0 ? (
            <div className="empty">Nenhuma solicitação pendente.</div>
          ) : (
            <ul className="match-list">
              {outgoing.map((r) => {
                const p = profiles[r.receiver]
                return (
                  <li key={r.id} className="match-row">
                    <div className="match-player">
                      <Avatar name={p?.display_name || p?.username} src={p?.avatar_url} size={34} />
                      <div>
                        <strong>{p?.display_name || p?.username || 'Jogador'}</strong>
                        <span className="muted small">Aguardando resposta</span>
                      </div>
                    </div>
                    <span className="status status-pending">pendente</span>
                  </li>
                )
              })}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}
