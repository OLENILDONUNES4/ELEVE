import { useEffect, useState, type FormEvent } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { useWallet } from '../context/WalletContext'
import { brl, errorMessage, shortDate } from '../lib/format'
import { Avatar } from '../components/Avatar'
import type { PlayerStat } from '../types'

export function ProfilePage() {
  const { user, profile, refreshProfile } = useAuth()
  const { balance, locked } = useWallet()

  const [displayName, setDisplayName] = useState('')
  const [bio, setBio] = useState('')
  const [avatarUrl, setAvatarUrl] = useState('')
  const [stats, setStats] = useState<PlayerStat | null>(null)
  const [feedback, setFeedback] = useState<{ kind: 'error' | 'info'; text: string } | null>(null)
  const [password, setPassword] = useState('')
  const [pwFeedback, setPwFeedback] = useState<{ kind: 'error' | 'info'; text: string } | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!profile) return
    setDisplayName(profile.display_name ?? '')
    setBio(profile.bio ?? '')
    setAvatarUrl(profile.avatar_url ?? '')
  }, [profile])

  useEffect(() => {
    if (!user) return
    supabase
      .from('player_stats')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => setStats((data as PlayerStat) ?? null))
  }, [user])

  async function saveProfile(e: FormEvent) {
    e.preventDefault()
    if (!user) return
    setFeedback(null)
    setBusy(true)
    const { error } = await supabase
      .from('profiles')
      .update({
        display_name: displayName.trim() || profile?.username,
        bio: bio.trim() || null,
        avatar_url: avatarUrl.trim() || null
      })
      .eq('id', user.id)
    setBusy(false)
    if (error) {
      setFeedback({ kind: 'error', text: errorMessage(error) })
      return
    }
    setFeedback({ kind: 'info', text: 'Perfil atualizado!' })
    await refreshProfile()
  }

  async function changePassword(e: FormEvent) {
    e.preventDefault()
    setPwFeedback(null)
    if (password.length < 6) {
      setPwFeedback({ kind: 'error', text: 'A senha deve ter pelo menos 6 caracteres.' })
      return
    }
    setBusy(true)
    const { error } = await supabase.auth.updateUser({ password })
    setBusy(false)
    if (error) {
      setPwFeedback({ kind: 'error', text: errorMessage(error) })
      return
    }
    setPassword('')
    setPwFeedback({ kind: 'info', text: 'Senha alterada com sucesso.' })
  }

  const winRate =
    stats && stats.matches > 0 ? Math.round((stats.wins / stats.matches) * 100) : 0

  return (
    <div className="container page">
      <header className="page-head">
        <h1>Meu perfil</h1>
        <p className="muted">Gerencie seus dados e acompanhe suas estatísticas.</p>
      </header>

      <div className="profile-head card">
        <Avatar name={profile?.display_name || profile?.username} src={avatarUrl || profile?.avatar_url} size={72} />
        <div>
          <h2>{profile?.display_name || profile?.username}</h2>
          <span className="muted">@{profile?.username}</span>
          <span className="muted small">Conta criada em {shortDate(profile?.created_at)}</span>
        </div>
        <div className="profile-money">
          <div>
            <span className="muted small">Disponível</span>
            <strong>{brl(balance)}</strong>
          </div>
          <div>
            <span className="muted small">Bloqueado</span>
            <strong>{brl(locked)}</strong>
          </div>
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat-card">
          <span>Partidas</span>
          <strong>{stats?.matches ?? 0}</strong>
        </div>
        <div className="stat-card">
          <span>Vitórias</span>
          <strong className="win">{stats?.wins ?? 0}</strong>
        </div>
        <div className="stat-card">
          <span>Derrotas</span>
          <strong className="loss">{stats?.losses ?? 0}</strong>
        </div>
        <div className="stat-card">
          <span>Aproveitamento</span>
          <strong>{winRate}%</strong>
        </div>
        <div className="stat-card">
          <span>Ganhos</span>
          <strong className="earn">{brl(stats?.earnings)}</strong>
        </div>
      </div>

      <div className="two-col">
        <section className="card">
          <h2>Editar perfil</h2>
          <form onSubmit={saveProfile} className="stack">
            <label className="field">
              <span>Nome de exibição</span>
              <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
            </label>
            <label className="field">
              <span>URL do avatar</span>
              <input
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                placeholder="https://…"
              />
            </label>
            <label className="field">
              <span>Bio</span>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={3}
                placeholder="Conte um pouco sobre você"
              />
            </label>
            {feedback && (
              <div className={`alert alert-${feedback.kind === 'error' ? 'error' : 'info'}`}>
                {feedback.text}
              </div>
            )}
            <button className="btn btn-primary" disabled={busy}>
              Salvar alterações
            </button>
          </form>
        </section>

        <section className="card">
          <h2>Alterar senha</h2>
          <form onSubmit={changePassword} className="stack">
            <label className="field">
              <span>Nova senha</span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="mínimo 6 caracteres"
                autoComplete="new-password"
              />
            </label>
            {pwFeedback && (
              <div className={`alert alert-${pwFeedback.kind === 'error' ? 'error' : 'info'}`}>
                {pwFeedback.text}
              </div>
            )}
            <button className="btn btn-ghost" disabled={busy}>
              Atualizar senha
            </button>
          </form>
        </section>
      </div>
    </div>
  )
}
