import { useCallback, useEffect, useState, type FormEvent } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { useWallet } from '../context/WalletContext'
import { brl, errorMessage, shortDate, toNumber } from '../lib/format'
import type { Deposit, Transaction, Withdrawal } from '../types'

type Method = 'pix' | 'crypto' | 'card'

const TYPE_LABEL: Record<string, string> = {
  deposit: 'Depósito',
  withdraw: 'Saque',
  stake: 'Aposta',
  payout: 'Prêmio',
  refund: 'Devolução',
  commission: 'Comissão',
  bonus: 'Bônus',
  adjustment: 'Ajuste'
}

export function Wallet() {
  const { user } = useAuth()
  const { balance, locked, refresh } = useWallet()

  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [deposits, setDeposits] = useState<Deposit[]>([])
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([])
  const [loading, setLoading] = useState(true)

  const [tab, setTab] = useState<'deposit' | 'withdraw'>('deposit')
  const [amount, setAmount] = useState('')
  const [method, setMethod] = useState<Method>('pix')
  const [pixKey, setPixKey] = useState('')
  const [feedback, setFeedback] = useState<{ kind: 'error' | 'info'; text: string } | null>(null)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    if (!user) return
    setLoading(true)
    const [tx, dp, wd] = await Promise.all([
      supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50),
      supabase
        .from('deposits')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20),
      supabase
        .from('withdrawals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20)
    ])
    setTransactions((tx.data as Transaction[]) ?? [])
    setDeposits((dp.data as Deposit[]) ?? [])
    setWithdrawals((wd.data as Withdrawal[]) ?? [])
    setLoading(false)
  }, [user])

  useEffect(() => {
    load()
  }, [load])

  async function handleDeposit(e: FormEvent) {
    e.preventDefault()
    setFeedback(null)
    const value = Number(amount.replace(',', '.'))
    if (!value || value < 1) {
      setFeedback({ kind: 'error', text: 'Informe um valor válido (mínimo R$ 1,00).' })
      return
    }
    setBusy(true)
    try {
      const { data, error } = await supabase.rpc('create_deposit', {
        p_amount: value,
        p_method: method
      })
      if (error) throw error
      // Gateway simulado: confirma o pagamento imediatamente.
      const { error: payError } = await supabase.rpc('pay_deposit', { p_deposit_id: data })
      if (payError) throw payError
      setFeedback({ kind: 'info', text: `Depósito de ${brl(value)} confirmado (simulado).` })
      setAmount('')
      await Promise.all([refresh(), load()])
    } catch (err) {
      setFeedback({ kind: 'error', text: errorMessage(err) })
    } finally {
      setBusy(false)
    }
  }

  async function handleWithdraw(e: FormEvent) {
    e.preventDefault()
    setFeedback(null)
    const value = Number(amount.replace(',', '.'))
    if (!value || value < 20) {
      setFeedback({ kind: 'error', text: 'O saque mínimo é de R$ 20,00.' })
      return
    }
    if (method === 'pix' && pixKey.trim().length < 5) {
      setFeedback({ kind: 'error', text: 'Informe uma chave Pix válida.' })
      return
    }
    setBusy(true)
    try {
      const { error } = await supabase.rpc('request_withdrawal', {
        p_amount: value,
        p_method: method === 'card' ? 'pix' : method,
        p_pix_key: pixKey.trim()
      })
      if (error) throw error
      setFeedback({ kind: 'info', text: `Saque de ${brl(value)} solicitado.` })
      setAmount('')
      setPixKey('')
      await Promise.all([refresh(), load()])
    } catch (err) {
      setFeedback({ kind: 'error', text: errorMessage(err) })
    } finally {
      setBusy(false)
    }
  }

  const total = balance + locked

  return (
    <div className="container page">
      <header className="page-head">
        <h1>Carteira</h1>
        <p className="muted">Deposite, saque e acompanhe seu extrato.</p>
      </header>

      <div className="wallet-cards">
        <div className="wallet-card primary">
          <span>Saldo disponível</span>
          <strong>{brl(balance)}</strong>
        </div>
        <div className="wallet-card">
          <span>Em partidas / saques</span>
          <strong>{brl(locked)}</strong>
        </div>
        <div className="wallet-card">
          <span>Total</span>
          <strong>{brl(total)}</strong>
        </div>
      </div>

      <div className="two-col">
        <section className="card">
          <div className="tabs">
            <button
              className={tab === 'deposit' ? 'active' : ''}
              onClick={() => {
                setTab('deposit')
                setFeedback(null)
                setMethod('pix')
              }}
            >
              Depositar
            </button>
            <button
              className={tab === 'withdraw' ? 'active' : ''}
              onClick={() => {
                setTab('withdraw')
                setFeedback(null)
                setMethod('pix')
              }}
            >
              Sacar
            </button>
          </div>

          <form onSubmit={tab === 'deposit' ? handleDeposit : handleWithdraw} className="stack">
            <label className="field">
              <span>Valor (R$)</span>
              <input
                inputMode="decimal"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0,00"
              />
            </label>

            <div className="field">
              <span>Método</span>
              <div className="chip-row">
                {(tab === 'deposit'
                  ? (['pix', 'crypto', 'card'] as Method[])
                  : (['pix', 'crypto'] as Method[])
                ).map((m) => (
                  <button
                    type="button"
                    key={m}
                    className={`chip ${method === m ? 'active' : ''}`}
                    onClick={() => setMethod(m)}
                  >
                    {m === 'pix' ? 'Pix' : m === 'crypto' ? 'Cripto' : 'Cartão'}
                  </button>
                ))}
              </div>
            </div>

            {tab === 'withdraw' && method === 'pix' && (
              <label className="field">
                <span>Chave Pix</span>
                <input
                  value={pixKey}
                  onChange={(e) => setPixKey(e.target.value)}
                  placeholder="CPF, e-mail, telefone ou chave aleatória"
                />
              </label>
            )}

            <div className="quick-amounts">
              {[20, 50, 100, 200].map((v) => (
                <button type="button" key={v} className="chip" onClick={() => setAmount(String(v))}>
                  +{v}
                </button>
              ))}
            </div>

            {feedback && (
              <div className={`alert alert-${feedback.kind === 'error' ? 'error' : 'info'}`}>
                {feedback.text}
              </div>
            )}

            <button className="btn btn-primary btn-block" disabled={busy}>
              {busy ? 'Processando…' : tab === 'deposit' ? 'Depositar' : 'Solicitar saque'}
            </button>
            {tab === 'deposit' && (
              <p className="muted small">
                Pagamento simulado para demonstração. Em produção, integre um gateway real
                (Pix, cripto ou cartão).
              </p>
            )}
          </form>
        </section>

        <section className="card">
          <h2>Extrato</h2>
          {loading ? (
            <div className="loading-block">Carregando…</div>
          ) : transactions.length === 0 ? (
            <div className="empty">Nenhuma movimentação ainda.</div>
          ) : (
            <ul className="tx-list">
              {transactions.map((tx) => {
                const positive = toNumber(tx.amount) >= 0
                return (
                  <li key={tx.id} className="tx-item">
                    <div>
                      <strong>{tx.description || TYPE_LABEL[tx.type] || tx.type}</strong>
                      <span className="muted small">{shortDate(tx.created_at)}</span>
                    </div>
                    <span className={`tx-amount ${positive ? 'pos' : 'neg'}`}>
                      {positive ? '+' : ''}
                      {brl(tx.amount)}
                    </span>
                  </li>
                )
              })}
            </ul>
          )}
        </section>
      </div>

      <div className="two-col">
        <section className="card">
          <h2>Depósitos</h2>
          {deposits.length === 0 ? (
            <div className="empty">Sem depósitos.</div>
          ) : (
            <ul className="tx-list">
              {deposits.map((d) => (
                <li key={d.id} className="tx-item">
                  <div>
                    <strong>{brl(d.amount)}</strong>
                    <span className="muted small">
                      {d.method.toUpperCase()} · {shortDate(d.created_at)}
                    </span>
                  </div>
                  <span className={`status status-${d.status}`}>{d.status}</span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card">
          <h2>Saques</h2>
          {withdrawals.length === 0 ? (
            <div className="empty">Sem saques.</div>
          ) : (
            <ul className="tx-list">
              {withdrawals.map((w) => (
                <li key={w.id} className="tx-item">
                  <div>
                    <strong>{brl(w.amount)}</strong>
                    <span className="muted small">
                      {w.method.toUpperCase()} · {shortDate(w.created_at)}
                    </span>
                  </div>
                  <span className={`status status-${w.status}`}>{w.status}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}
