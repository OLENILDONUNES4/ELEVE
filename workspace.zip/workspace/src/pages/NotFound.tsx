import { Link } from 'react-router-dom'

export function NotFound() {
  return (
    <div className="container page">
      <div className="empty-state">
        <h1>404</h1>
        <p className="muted">Página não encontrada.</p>
        <Link to="/" className="btn btn-primary">
          Voltar para o início
        </Link>
      </div>
    </div>
  )
}
