import { BrowserRouter, Route, Routes } from 'react-router-dom'
import type { ReactNode } from 'react'
import { AuthProvider } from './context/AuthContext'
import { WalletProvider } from './context/WalletContext'
import { Layout } from './components/Layout'
import { ProtectedRoute } from './components/ProtectedRoute'
import { Home } from './pages/Home'
import { Login } from './pages/Login'
import { Register } from './pages/Register'
import { Wallet } from './pages/Wallet'
import { Ranking } from './pages/Ranking'
import { Friends } from './pages/Friends'
import { Affiliates } from './pages/Affiliates'
import { ProfilePage } from './pages/Profile'
import { Support } from './pages/Support'
import { GamePage } from './pages/GamePage'
import { NotFound } from './pages/NotFound'

function protect(node: ReactNode) {
  return <ProtectedRoute>{node}</ProtectedRoute>
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <WalletProvider>
          <Routes>
            <Route element={<Layout />}>
              <Route path="/" element={<Home />} />
              <Route path="/entrar" element={<Login />} />
              <Route path="/cadastrar" element={<Register />} />
              <Route path="/ranking" element={<Ranking />} />
              <Route path="/carteira" element={protect(<Wallet />)} />
              <Route path="/amigos" element={protect(<Friends />)} />
              <Route path="/afiliados" element={protect(<Affiliates />)} />
              <Route path="/perfil" element={protect(<ProfilePage />)} />
              <Route path="/suporte" element={protect(<Support />)} />
              <Route path="/jogo/:slug" element={protect(<GamePage />)} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </WalletProvider>
      </AuthProvider>
    </BrowserRouter>
  )
}
