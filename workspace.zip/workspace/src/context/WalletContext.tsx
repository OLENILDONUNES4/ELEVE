import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode
} from 'react'
import { supabase } from '../lib/supabase'
import { toNumber } from '../lib/format'
import type { Wallet } from '../types'
import { useAuth } from './AuthContext'

interface WalletValue {
  wallet: Wallet | null
  balance: number
  locked: number
  loading: boolean
  refresh: () => Promise<void>
}

const WalletContext = createContext<WalletValue | undefined>(undefined)

export function WalletProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  const [wallet, setWallet] = useState<Wallet | null>(null)
  const [loading, setLoading] = useState(false)

  const refresh = useCallback(async () => {
    if (!user) {
      setWallet(null)
      return
    }
    setLoading(true)
    const { data } = await supabase
      .from('wallets')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle()
    setWallet((data as Wallet) ?? null)
    setLoading(false)
  }, [user])

  useEffect(() => {
    refresh()
  }, [refresh])

  const value = useMemo<WalletValue>(
    () => ({
      wallet,
      balance: toNumber(wallet?.balance),
      locked: toNumber(wallet?.locked),
      loading,
      refresh
    }),
    [wallet, loading, refresh]
  )

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>
}

// eslint-disable-next-line react-refresh/only-export-components
export function useWallet(): WalletValue {
  const ctx = useContext(WalletContext)
  if (!ctx) throw new Error('useWallet deve ser usado dentro de WalletProvider')
  return ctx
}
