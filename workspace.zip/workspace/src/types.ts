export interface Profile {
  id: string
  username: string
  display_name: string | null
  avatar_url: string | null
  bio: string | null
  referred_by: string | null
  is_admin: boolean
  created_at: string
}

export interface Wallet {
  user_id: string
  balance: number | string
  locked: number | string
  updated_at: string
}

export type TransactionType =
  | 'deposit'
  | 'withdraw'
  | 'stake'
  | 'payout'
  | 'refund'
  | 'commission'
  | 'bonus'
  | 'adjustment'

export interface Transaction {
  id: string
  user_id: string
  type: TransactionType
  amount: number | string
  balance_after: number | string | null
  status: 'pending' | 'completed' | 'failed' | 'cancelled'
  description: string | null
  metadata: Record<string, unknown>
  created_at: string
}

export interface Deposit {
  id: string
  user_id: string
  method: 'pix' | 'crypto' | 'card'
  amount: number | string
  status: 'pending' | 'paid' | 'failed' | 'expired'
  reference: string | null
  created_at: string
  paid_at: string | null
}

export interface Withdrawal {
  id: string
  user_id: string
  method: 'pix' | 'crypto'
  amount: number | string
  pix_key: string | null
  status: 'pending' | 'processing' | 'paid' | 'rejected'
  created_at: string
  processed_at: string | null
}

export interface Match {
  id: string
  game_slug: string
  stake: number | string
  player_x: string
  player_o: string | null
  board: string[]
  turn: 'X' | 'O'
  status: 'waiting' | 'active' | 'finished' | 'cancelled'
  winner: string | null
  result: 'x_win' | 'o_win' | 'draw' | 'cancelled' | null
  pot: number | string
  created_at: string
  updated_at: string
}

export interface PlayerStat {
  user_id: string
  wins: number
  losses: number
  draws: number
  matches: number
  earnings: number | string
}

export interface RankRow {
  id: string
  username: string
  display_name: string | null
  avatar_url: string | null
  wins: number
  losses: number
  draws: number
  matches: number
  earnings: number | string
}

export interface FriendRequest {
  id: string
  sender: string
  receiver: string
  status: 'pending' | 'accepted' | 'rejected'
  created_at: string
}

export interface Friendship {
  id: string
  user_a: string
  user_b: string
  created_at: string
}

export interface AffiliateEarning {
  id: string
  affiliate_id: string
  referred_id: string
  amount: number | string
  kind: string
  description: string | null
  created_at: string
}

export interface SupportTicket {
  id: string
  user_id: string | null
  guest_email: string | null
  subject: string
  category: string
  status: 'open' | 'answered' | 'closed'
  created_at: string
  updated_at: string
}

export interface SupportMessage {
  id: string
  ticket_id: string
  author_id: string | null
  is_staff: boolean
  body: string
  read_at: string | null
  created_at: string
}

export interface GameDef {
  slug: string
  name: string
  short: string
  description: string
  icon: string
  available: boolean
  minStake: number
}

export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile }
      wallets: { Row: Wallet }
      transactions: { Row: Transaction }
      deposits: { Row: Deposit }
      withdrawals: { Row: Withdrawal }
      matches: { Row: Match }
      player_stats: { Row: PlayerStat }
      friend_requests: { Row: FriendRequest }
      friendships: { Row: Friendship }
      affiliate_earnings: { Row: AffiliateEarning }
      support_tickets: { Row: SupportTicket }
      support_messages: { Row: SupportMessage }
    }
    Views: {
      ranking: { Row: RankRow }
    }
    Functions: {
      create_match: { Args: { p_game_slug: string; p_stake: number }; Returns: string }
      join_match: { Args: { p_match_id: string }; Returns: void }
      cancel_match: { Args: { p_match_id: string }; Returns: void }
      make_move: { Args: { p_match_id: string; p_index: number }; Returns: Match }
      create_deposit: { Args: { p_amount: number; p_method: string }; Returns: string }
      pay_deposit: { Args: { p_deposit_id: string }; Returns: void }
      request_withdrawal: { Args: { p_amount: number; p_method: string; p_pix_key: string }; Returns: string }
    }
  }
}
