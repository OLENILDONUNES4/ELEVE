export function brl(value: number | string | null | undefined): string {
  const n = toNumber(value)
  return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}

export function toNumber(value: number | string | null | undefined): number {
  if (value == null) return 0
  const n = typeof value === 'string' ? parseFloat(value) : value
  return Number.isFinite(n) ? n : 0
}

export function shortDate(iso: string | null | undefined): string {
  if (!iso) return '-'
  const d = new Date(iso)
  return d.toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

export function relativeTime(iso: string | null | undefined): string {
  if (!iso) return ''
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'agora'
  if (mins < 60) return `${mins} min`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours} h`
  const days = Math.floor(hours / 24)
  return `${days} d`
}

export function initials(name: string | null | undefined): string {
  if (!name) return '?'
  const parts = name.trim().split(/\s+/)
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

export function errorMessage(err: unknown, fallback = 'Algo deu errado. Tente novamente.'): string {
  if (!err) return fallback
  if (typeof err === 'string') return err
  const msg = (err as { message?: string }).message
  return msg ? translate(msg) : fallback
}

function translate(msg: string): string {
  const map: Record<string, string> = {
    'Invalid login credentials': 'E-mail ou senha invalidos.',
    'User already registered': 'Este e-mail ja esta cadastrado.',
    'Email not confirmed': 'Confirme seu e-mail antes de entrar.',
    'Password should be at least 6 characters':
      'A senha deve ter pelo menos 6 caracteres.',
    'saldo insuficiente': 'Saldo insuficiente.',
    'not authenticated': 'Voce precisa estar logado.',
    'nao autenticado': 'Voce precisa estar logado.'
  }
  return map[msg] ?? msg
}
