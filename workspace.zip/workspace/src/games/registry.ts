import type { GameDef } from '../types'

export const GAMES: GameDef[] = [
  {
    slug: 'truco',
    name: 'Truco X1',
    short: 'Truco',
    description: 'Truco paulista, 2 jogadores, manilhas e tentos. Suba a aposta e blefe com estilo.',
    icon: '🃏',
    available: false,
    minStake: 5
  },
  {
    slug: 'buraco',
    name: 'Buraco X1',
    short: 'Buraco',
    description: 'Buraco fechado 1v1 com dois baralhos. Estrategia pura para montar jogos e canastras.',
    icon: '🗂️',
    available: false,
    minStake: 5
  },
  {
    slug: 'domino',
    name: 'Dominó X1',
    short: 'Dominó',
    description: 'Dominó de duplas 1v1, bate e corre. Feche o jogo antes do adversario.',
    icon: '🁫',
    available: false,
    minStake: 5
  },
  {
    slug: 'dama',
    name: 'Damas X1',
    short: 'Damas',
    description: 'Damas brasileiras 8x8, 12 pecas para cada lado. Capture e coroe suas pedras.',
    icon: '⚪',
    available: false,
    minStake: 5
  },
  {
    slug: 'xadrez',
    name: 'Xadrez X1',
    short: 'Xadrez',
    description: 'Xadrez completo: roque, en passant e promocao incluidos.',
    icon: '♞',
    available: false,
    minStake: 5
  },
  {
    slug: 'sinuca',
    name: 'Sinuca X1',
    short: 'Sinuca',
    description: 'Sinuca de bola 8. Encaçape a bola certa e deixe a mesa limpa.',
    icon: '🎱',
    available: false,
    minStake: 5
  },
  {
    slug: 'forca',
    name: 'Forca X1',
    short: 'Forca',
    description: 'Duelo de palavras. Descubra a palavra secreta antes do oponente.',
    icon: '🔤',
    available: false,
    minStake: 5
  },
  {
    slug: 'ronda',
    name: 'Ronda X1',
    short: 'Ronda',
    description: 'Ronda de cartas, quem fizer 15 pontos primeiro leva a mesa.',
    icon: '🎴',
    available: false,
    minStake: 5
  },
  {
    slug: 'jogodavelha',
    name: 'Jogo da Velha X1',
    short: 'Jogo da Velha',
    description: 'O classico 3x3 em partidas 1v1 em tempo real. Rapido, direto e com aposta.',
    icon: '⭕',
    available: true,
    minStake: 0
  }
]

export function getGame(slug: string | undefined): GameDef | undefined {
  return GAMES.find((g) => g.slug === slug)
}
