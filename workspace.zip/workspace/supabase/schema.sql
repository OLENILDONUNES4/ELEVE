-- ============================================================================
-- Games X1 - Schema Supabase
-- Rode este arquivo inteiro no SQL Editor do Supabase (Database > SQL Editor).
-- Ele cria: tabelas, RLS, funcoes RPC (apostas com escrow), estatisticas,
-- indicacao (afiliados), suporte, ranking e Realtime.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Tabelas
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text,
  avatar_url text,
  bio text,
  referred_by uuid references public.profiles(id) on delete set null,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  balance numeric(14,2) not null default 0 check (balance >= 0),
  locked  numeric(14,2) not null default 0 check (locked >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('deposit','withdraw','stake','payout','refund','commission','bonus','adjustment')),
  amount numeric(14,2) not null,
  balance_after numeric(14,2),
  status text not null default 'completed' check (status in ('pending','completed','failed','cancelled')),
  description text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists transactions_user_idx on public.transactions (user_id, created_at desc);

create table if not exists public.deposits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  method text not null check (method in ('pix','crypto','card')),
  amount numeric(14,2) not null check (amount > 0),
  status text not null default 'pending' check (status in ('pending','paid','failed','expired')),
  reference text,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);
create index if not exists deposits_user_idx on public.deposits (user_id, created_at desc);

create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  method text not null default 'pix' check (method in ('pix','crypto')),
  amount numeric(14,2) not null check (amount > 0),
  pix_key text,
  status text not null default 'pending' check (status in ('pending','processing','paid','rejected')),
  created_at timestamptz not null default now(),
  processed_at timestamptz
);
create index if not exists withdrawals_user_idx on public.withdrawals (user_id, created_at desc);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  game_slug text not null,
  stake numeric(14,2) not null default 0 check (stake >= 0),
  player_x uuid not null references public.profiles(id) on delete cascade,
  player_o uuid references public.profiles(id) on delete set null,
  board jsonb not null default '["","","","","","","","",""]'::jsonb,
  turn text not null default 'X' check (turn in ('X','O')),
  status text not null default 'waiting' check (status in ('waiting','active','finished','cancelled')),
  winner uuid references public.profiles(id) on delete set null,
  result text check (result in ('x_win','o_win','draw','cancelled')),
  pot numeric(14,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists matches_status_idx on public.matches (status, created_at desc);
create index if not exists matches_game_idx on public.matches (game_slug, status);

create table if not exists public.player_stats (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  wins int not null default 0,
  losses int not null default 0,
  draws int not null default 0,
  matches int not null default 0,
  earnings numeric(14,2) not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender uuid not null references public.profiles(id) on delete cascade,
  receiver uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(),
  unique (sender, receiver)
);

create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_a, user_b),
  check (user_a < user_b)
);

create table if not exists public.affiliate_earnings (
  id uuid primary key default gen_random_uuid(),
  affiliate_id uuid not null references public.profiles(id) on delete cascade,
  referred_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(14,2) not null,
  kind text not null default 'commission',
  description text,
  created_at timestamptz not null default now()
);
create index if not exists affiliate_earnings_idx on public.affiliate_earnings (affiliate_id, created_at desc);

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  guest_email text,
  subject text not null,
  category text not null default 'geral',
  status text not null default 'open' check (status in ('open','answered','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.support_tickets(id) on delete cascade,
  author_id uuid references public.profiles(id) on delete set null,
  is_staff boolean not null default false,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists support_messages_ticket_idx on public.support_messages (ticket_id, created_at);

-- ---------------------------------------------------------------------------
-- 2. Helpers
-- ---------------------------------------------------------------------------

-- Cria perfil + carteira + stats automaticamente quando um usuario se cadastra
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  uname text;
  v_referred uuid;
begin
  uname := coalesce(nullif(new.raw_user_meta_data->>'username',''), 'player_' || substr(new.id::text, 1, 8));

  if exists (select 1 from public.profiles where username = uname) then
    uname := uname || '_' || floor(random() * 9000 + 1000)::int::text;
  end if;

  begin
    v_referred := nullif(new.raw_user_meta_data->>'referred_by','')::uuid;
  exception when others then
    v_referred := null;
  end;

  insert into public.profiles (id, username, display_name, referred_by)
  values (new.id, uname, coalesce(nullif(new.raw_user_meta_data->>'display_name',''), uname), v_referred)
  on conflict (id) do nothing;

  insert into public.wallets (user_id, balance) values (new.id, 100.00)
  on conflict (user_id) do nothing;

  insert into public.player_stats (user_id) values (new.id)
  on conflict (user_id) do nothing;

  insert into public.transactions (user_id, type, amount, balance_after, status, description)
  values (new.id, 'bonus', 100.00, 100.00, 'completed', 'Bonus de boas-vindas');

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Insere um lancamento no extrato (ledger)
create or replace function public.add_transaction(
  p_user uuid,
  p_type text,
  p_amount numeric,
  p_desc text default null,
  p_status text default 'completed',
  p_meta jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
  v_balance numeric;
begin
  select balance into v_balance from public.wallets where user_id = p_user;
  insert into public.transactions (user_id, type, amount, status, description, metadata, balance_after)
  values (p_user, p_type, p_amount, p_status, p_desc, coalesce(p_meta, '{}'::jsonb), v_balance)
  returning id into v_id;
  return v_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- 3. RPCs de carteira
-- ---------------------------------------------------------------------------

-- Cria um deposito pendente (o gateway de pagamento real confirma depois)
create or replace function public.create_deposit(p_amount numeric, p_method text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_id uuid;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;
  if p_method not in ('pix','crypto','card') then raise exception 'metodo invalido'; end if;
  if p_amount is null or p_amount < 1 or p_amount > 100000 then raise exception 'valor invalido'; end if;

  insert into public.deposits (user_id, method, amount, status, reference)
  values (v_user, p_method, p_amount, 'pending', 'dep_' || substr(gen_random_uuid()::text, 1, 12))
  returning id into v_id;

  return v_id;
end;
$$;

-- Gateway SIMULADO: confirma o deposito e credita o saldo + comissao de afiliado.
-- Em producao, troque por um webhook assinado do provedor de pagamento.
create or replace function public.pay_deposit(p_deposit_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_dep public.deposits;
  v_referrer uuid;
  v_commission numeric;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;

  select * into v_dep from public.deposits where id = p_deposit_id and user_id = v_user for update;
  if not found then raise exception 'deposito nao encontrado'; end if;
  if v_dep.status <> 'pending' then raise exception 'deposito ja processado'; end if;

  update public.deposits set status = 'paid', paid_at = now() where id = p_deposit_id;
  update public.wallets set balance = balance + v_dep.amount, updated_at = now() where user_id = v_user;
  perform public.add_transaction(v_user, 'deposit', v_dep.amount, 'Deposito via ' || upper(v_dep.method), 'completed',
    jsonb_build_object('deposit', p_deposit_id, 'method', v_dep.method));

  select referred_by into v_referrer from public.profiles where id = v_user;
  if v_referrer is not null then
    v_commission := round(v_dep.amount * 0.05, 2);
    update public.wallets set balance = balance + v_commission, updated_at = now() where user_id = v_referrer;
    perform public.add_transaction(v_referrer, 'commission', v_commission, 'Comissao de indicacao', 'completed',
      jsonb_build_object('from', v_user));
    insert into public.affiliate_earnings (affiliate_id, referred_id, amount, kind, description)
    values (v_referrer, v_user, v_commission, 'commission', 'Comissao sobre deposito');
  end if;
end;
$$;

-- Solicita saque: bloqueia o valor do saldo
create or replace function public.request_withdrawal(p_amount numeric, p_method text, p_pix_key text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_balance numeric;
  v_id uuid;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;
  if p_method not in ('pix','crypto') then raise exception 'metodo invalido'; end if;
  if p_amount is null or p_amount < 20 then raise exception 'valor minimo de R$ 20,00'; end if;

  select balance into v_balance from public.wallets where user_id = v_user for update;
  if not found then raise exception 'carteira nao encontrada'; end if;
  if v_balance < p_amount then raise exception 'saldo insuficiente'; end if;

  update public.wallets set balance = balance - p_amount, locked = locked + p_amount, updated_at = now()
  where user_id = v_user;

  insert into public.withdrawals (user_id, method, amount, pix_key, status)
  values (v_user, p_method, p_amount, p_pix_key, 'pending')
  returning id into v_id;

  perform public.add_transaction(v_user, 'withdraw', -p_amount, 'Saque solicitado', 'pending',
    jsonb_build_object('withdrawal', v_id, 'method', p_method));

  return v_id;
end;
$$;

-- Admin/staff confirma ou recusa um saque
create or replace function public.settle_withdrawal(p_id uuid, p_status text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_admin uuid := auth.uid();
  v_w public.withdrawals;
begin
  if not exists (select 1 from public.profiles where id = v_admin and is_admin) then
    raise exception 'acesso restrito';
  end if;
  if p_status not in ('paid','rejected') then raise exception 'status invalido'; end if;

  select * into v_w from public.withdrawals where id = p_id for update;
  if not found then raise exception 'saque nao encontrado'; end if;
  if v_w.status not in ('pending','processing') then raise exception 'saque ja processado'; end if;

  update public.withdrawals set status = p_status, processed_at = now() where id = p_id;

  if p_status = 'paid' then
    update public.wallets set locked = locked - v_w.amount, updated_at = now() where user_id = v_w.user_id;
    update public.transactions set status = 'completed'
      where user_id = v_w.user_id and type = 'withdraw' and metadata->>'withdrawal' = p_id::text;
  else
    update public.wallets set locked = locked - v_w.amount, balance = balance + v_w.amount, updated_at = now()
    where user_id = v_w.user_id;
    perform public.add_transaction(v_w.user_id, 'refund', v_w.amount, 'Saque recusado - devolvido', 'completed',
      jsonb_build_object('withdrawal', p_id));
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 4. RPCs de partidas 1v1 (Jogo da Velha) com escrow
-- ---------------------------------------------------------------------------

create or replace function public.create_match(p_game_slug text, p_stake numeric)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_balance numeric;
  v_id uuid;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;
  if p_stake is null or p_stake < 0 then raise exception 'aposta invalida'; end if;

  select balance into v_balance from public.wallets where user_id = v_user for update;
  if not found then raise exception 'carteira nao encontrada'; end if;
  if v_balance < p_stake then raise exception 'saldo insuficiente'; end if;

  if p_stake > 0 then
    update public.wallets set balance = balance - p_stake, locked = locked + p_stake, updated_at = now()
    where user_id = v_user;
    perform public.add_transaction(v_user, 'stake', -p_stake, 'Aposta em partida', 'completed',
      jsonb_build_object('game', p_game_slug));
  end if;

  insert into public.matches (game_slug, stake, player_x, pot, status, turn)
  values (p_game_slug, p_stake, v_user, p_stake, 'waiting', 'X')
  returning id into v_id;

  return v_id;
end;
$$;

create or replace function public.join_match(p_match_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_match public.matches;
  v_balance numeric;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;

  select * into v_match from public.matches where id = p_match_id for update;
  if not found then raise exception 'partida nao encontrada'; end if;
  if v_match.status <> 'waiting' then raise exception 'partida indisponivel'; end if;
  if v_match.player_x = v_user then raise exception 'voce nao pode entrar na propria partida'; end if;

  select balance into v_balance from public.wallets where user_id = v_user for update;
  if v_balance < v_match.stake then raise exception 'saldo insuficiente'; end if;

  if v_match.stake > 0 then
    update public.wallets set balance = balance - v_match.stake, locked = locked + v_match.stake, updated_at = now()
    where user_id = v_user;
    perform public.add_transaction(v_user, 'stake', -v_match.stake, 'Aposta em partida', 'completed',
      jsonb_build_object('match', p_match_id));
  end if;

  update public.matches
  set player_o = v_user, status = 'active', pot = v_match.stake * 2, updated_at = now()
  where id = p_match_id;
end;
$$;

create or replace function public.cancel_match(p_match_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_match public.matches;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;

  select * into v_match from public.matches where id = p_match_id for update;
  if not found then raise exception 'partida nao encontrada'; end if;
  if v_match.player_x <> v_user then raise exception 'apenas o criador pode cancelar'; end if;
  if v_match.status <> 'waiting' then raise exception 'partida ja iniciada'; end if;

  if v_match.stake > 0 then
    update public.wallets set balance = balance + v_match.stake, locked = locked - v_match.stake, updated_at = now()
    where user_id = v_user;
    perform public.add_transaction(v_user, 'refund', v_match.stake, 'Partida cancelada - devolucao', 'completed',
      jsonb_build_object('match', p_match_id));
  end if;

  update public.matches set status = 'cancelled', result = 'cancelled', updated_at = now() where id = p_match_id;
end;
$$;

create or replace function public.make_move(p_match_id uuid, p_index int)
returns public.matches
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_match public.matches;
  v_board jsonb;
  v_mark text;
  v_lines int[] := array[0,1,2, 3,4,5, 6,7,8, 0,3,6, 1,4,7, 2,5,8, 0,4,8, 2,4,6];
  v_i int;
  v_a int; v_b int; v_c int;
  v_result text := null;
  v_winner uuid := null;
  v_payout numeric := 0;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;

  select * into v_match from public.matches where id = p_match_id for update;
  if not found then raise exception 'partida nao encontrada'; end if;
  if v_match.status <> 'active' then raise exception 'partida nao esta ativa'; end if;
  if v_user not in (v_match.player_x, v_match.player_o) then raise exception 'voce nao e jogador'; end if;

  v_mark := case when v_user = v_match.player_x then 'X' else 'O' end;
  if v_mark <> v_match.turn then raise exception 'nao e a sua vez'; end if;
  if p_index < 0 or p_index > 8 then raise exception 'jogada invalida'; end if;

  v_board := v_match.board;
  if coalesce(v_board->>p_index, '') <> '' then raise exception 'casa ocupada'; end if;
  v_board := jsonb_set(v_board, array[p_index::text], to_jsonb(v_mark));

  for v_i in 0..7 loop
    v_a := v_lines[v_i*3 + 1];
    v_b := v_lines[v_i*3 + 2];
    v_c := v_lines[v_i*3 + 3];
    if v_board->>v_a = v_mark and v_board->>v_b = v_mark and v_board->>v_c = v_mark then
      v_result := lower(v_mark) || '_win';
    end if;
  end loop;

  if v_result is null and not exists (
    select 1 from jsonb_array_elements_text(v_board) e where e = ''
  ) then
    v_result := 'draw';
  end if;

  if v_result is null then
    update public.matches
    set board = v_board, turn = case when v_match.turn = 'X' then 'O' else 'X' end, updated_at = now()
    where id = p_match_id
    returning * into v_match;
    return v_match;
  end if;

  if v_result <> 'draw' then
    v_winner := v_user;
  end if;

  update public.matches
  set board = v_board, status = 'finished', winner = v_winner, result = v_result, updated_at = now()
  where id = p_match_id
  returning * into v_match;

  if v_match.pot > 0 then
    update public.wallets set locked = locked - v_match.stake, updated_at = now() where user_id = v_match.player_x;
    update public.wallets set locked = locked - v_match.stake, updated_at = now() where user_id = v_match.player_o;

    if v_winner is not null then
      v_payout := v_match.pot - round(v_match.pot * 0.10, 2); -- rake de 10%
      update public.wallets set balance = balance + v_payout, updated_at = now() where user_id = v_winner;
      perform public.add_transaction(v_winner, 'payout', v_payout, 'Premio de partida', 'completed',
        jsonb_build_object('match', p_match_id));
    else
      update public.wallets set balance = balance + v_match.stake, updated_at = now() where user_id = v_match.player_x;
      update public.wallets set balance = balance + v_match.stake, updated_at = now() where user_id = v_match.player_o;
      perform public.add_transaction(v_match.player_x, 'refund', v_match.stake, 'Empate - devolucao', 'completed',
        jsonb_build_object('match', p_match_id));
      perform public.add_transaction(v_match.player_o, 'refund', v_match.stake, 'Empate - devolucao', 'completed',
        jsonb_build_object('match', p_match_id));
    end if;
  end if;

  update public.player_stats set matches = matches + 1, updated_at = now() where user_id = v_match.player_x;
  update public.player_stats set matches = matches + 1, updated_at = now() where user_id = v_match.player_o;

  if v_winner is not null then
    update public.player_stats
    set wins = wins + 1, earnings = earnings + v_payout, updated_at = now()
    where user_id = v_winner;
    update public.player_stats
    set losses = losses + 1, updated_at = now()
    where user_id = case when v_winner = v_match.player_x then v_match.player_o else v_match.player_x end;
  else
    update public.player_stats set draws = draws + 1, updated_at = now()
    where user_id in (v_match.player_x, v_match.player_o);
  end if;

  return v_match;
end;
$$;

-- ---------------------------------------------------------------------------
-- 4b. RPCs sociais (amigos)
-- ---------------------------------------------------------------------------

create or replace function public.send_friend_request(p_username text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_target uuid;
  v_id uuid;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;

  select id into v_target from public.profiles where username = p_username;
  if v_target is null then raise exception 'usuario nao encontrado'; end if;
  if v_target = v_user then raise exception 'voce nao pode adicionar a si mesmo'; end if;

  if exists (
    select 1 from public.friendships
    where (user_a = v_user and user_b = v_target) or (user_a = v_target and user_b = v_user)
  ) then
    raise exception 'voces ja sao amigos';
  end if;

  insert into public.friend_requests (sender, receiver, status)
  values (v_user, v_target, 'pending')
  on conflict (sender, receiver) do update set status = 'pending'
  returning id into v_id;

  return v_id;
end;
$$;

create or replace function public.respond_friend_request(p_request_id uuid, p_accept boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_req public.friend_requests;
  v_a uuid;
  v_b uuid;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;

  select * into v_req from public.friend_requests where id = p_request_id for update;
  if not found then raise exception 'solicitacao nao encontrada'; end if;
  if v_req.receiver <> v_user then raise exception 'sem permissao'; end if;
  if v_req.status <> 'pending' then raise exception 'solicitacao ja respondida'; end if;

  if p_accept then
    update public.friend_requests set status = 'accepted' where id = p_request_id;
    v_a := least(v_req.sender, v_req.receiver);
    v_b := greatest(v_req.sender, v_req.receiver);
    insert into public.friendships (user_a, user_b) values (v_a, v_b)
    on conflict (user_a, user_b) do nothing;
  else
    update public.friend_requests set status = 'rejected' where id = p_request_id;
  end if;
end;
$$;

create or replace function public.remove_friend(p_friend_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_a uuid;
  v_b uuid;
begin
  if v_user is null then raise exception 'nao autenticado'; end if;
  v_a := least(v_user, p_friend_id);
  v_b := greatest(v_user, p_friend_id);
  delete from public.friendships where user_a = v_a and user_b = v_b;
end;
$$;

-- ---------------------------------------------------------------------------
-- 5. Ranking (view)
-- ---------------------------------------------------------------------------
drop view if exists public.ranking;
create view public.ranking with (security_invoker = on) as
select
  p.id,
  p.username,
  p.display_name,
  p.avatar_url,
  s.wins,
  s.losses,
  s.draws,
  s.matches,
  s.earnings
from public.profiles p
join public.player_stats s on s.user_id = p.id;

-- ---------------------------------------------------------------------------
-- 6. Row Level Security
-- ---------------------------------------------------------------------------
alter table public.profiles          enable row level security;
alter table public.wallets           enable row level security;
alter table public.transactions      enable row level security;
alter table public.deposits          enable row level security;
alter table public.withdrawals       enable row level security;
alter table public.matches           enable row level security;
alter table public.player_stats      enable row level security;
alter table public.friend_requests   enable row level security;
alter table public.friendships       enable row level security;
alter table public.affiliate_earnings enable row level security;
alter table public.support_tickets   enable row level security;
alter table public.support_messages  enable row level security;

-- profiles: leitura publica (autenticado), edicao propria
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated using (true);

drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists profiles_insert on public.profiles;
create policy profiles_insert on public.profiles for insert to authenticated with check (id = auth.uid());

-- wallets
drop policy if exists wallets_select on public.wallets;
create policy wallets_select on public.wallets for select to authenticated using (user_id = auth.uid());

-- transactions
drop policy if exists transactions_select on public.transactions;
create policy transactions_select on public.transactions for select to authenticated using (user_id = auth.uid());

-- deposits
drop policy if exists deposits_select on public.deposits;
create policy deposits_select on public.deposits for select to authenticated using (user_id = auth.uid());

-- withdrawals
drop policy if exists withdrawals_select on public.withdrawals;
create policy withdrawals_select on public.withdrawals for select to authenticated using (user_id = auth.uid());

-- matches: lobby visivel para todos autenticados
drop policy if exists matches_select on public.matches;
create policy matches_select on public.matches for select to authenticated using (true);

-- player_stats: leitura publica
drop policy if exists player_stats_select on public.player_stats;
create policy player_stats_select on public.player_stats for select to authenticated using (true);

-- friend_requests
drop policy if exists friend_requests_select on public.friend_requests;
create policy friend_requests_select on public.friend_requests for select to authenticated
  using (sender = auth.uid() or receiver = auth.uid());

drop policy if exists friend_requests_insert on public.friend_requests;
create policy friend_requests_insert on public.friend_requests for insert to authenticated
  with check (sender = auth.uid());

drop policy if exists friend_requests_update on public.friend_requests;
create policy friend_requests_update on public.friend_requests for update to authenticated
  using (receiver = auth.uid()) with check (receiver = auth.uid());

-- friendships
drop policy if exists friendships_select on public.friendships;
create policy friendships_select on public.friendships for select to authenticated
  using (user_a = auth.uid() or user_b = auth.uid());

drop policy if exists friendships_delete on public.friendships;
create policy friendships_delete on public.friendships for delete to authenticated
  using (user_a = auth.uid() or user_b = auth.uid());

-- affiliate_earnings
drop policy if exists affiliate_earnings_select on public.affiliate_earnings;
create policy affiliate_earnings_select on public.affiliate_earnings for select to authenticated
  using (affiliate_id = auth.uid());

-- support
drop policy if exists support_tickets_select on public.support_tickets;
create policy support_tickets_select on public.support_tickets for select to authenticated
  using (user_id = auth.uid());

drop policy if exists support_tickets_insert on public.support_tickets;
create policy support_tickets_insert on public.support_tickets for insert to authenticated
  with check (user_id = auth.uid());

drop policy if exists support_messages_select on public.support_messages;
create policy support_messages_select on public.support_messages for select to authenticated
  using (exists (
    select 1 from public.support_tickets t
    where t.id = ticket_id and t.user_id = auth.uid()
  ));

drop policy if exists support_messages_insert on public.support_messages;
create policy support_messages_insert on public.support_messages for insert to authenticated
  with check (exists (
    select 1 from public.support_tickets t
    where t.id = ticket_id and t.user_id = auth.uid()
  ));

-- ---------------------------------------------------------------------------
-- 7. Realtime (atualizacao de partidas em tempo real)
-- ---------------------------------------------------------------------------
do $$
begin
  alter publication supabase_realtime add table public.matches;
exception when duplicate_object then null;
end $$;

-- ---------------------------------------------------------------------------
-- 8. Permissoes das funcoes
-- ---------------------------------------------------------------------------
revoke all on function public.create_deposit(numeric, text) from public, anon;
revoke all on function public.pay_deposit(uuid) from public, anon;
revoke all on function public.request_withdrawal(numeric, text, text) from public, anon;
revoke all on function public.create_match(text, numeric) from public, anon;
revoke all on function public.join_match(uuid) from public, anon;
revoke all on function public.cancel_match(uuid) from public, anon;
revoke all on function public.make_move(uuid, int) from public, anon;
revoke all on function public.settle_withdrawal(uuid, text) from public, anon;
revoke all on function public.send_friend_request(text) from public, anon;
revoke all on function public.respond_friend_request(uuid, boolean) from public, anon;
revoke all on function public.remove_friend(uuid) from public, anon;

grant execute on function public.create_deposit(numeric, text) to authenticated;
grant execute on function public.pay_deposit(uuid) to authenticated;
grant execute on function public.request_withdrawal(numeric, text, text) to authenticated;
grant execute on function public.create_match(text, numeric) to authenticated;
grant execute on function public.join_match(uuid) to authenticated;
grant execute on function public.cancel_match(uuid) to authenticated;
grant execute on function public.make_move(uuid, int) to authenticated;
grant execute on function public.settle_withdrawal(uuid, text) to authenticated;
grant execute on function public.send_friend_request(text) to authenticated;
grant execute on function public.respond_friend_request(uuid, boolean) to authenticated;
grant execute on function public.remove_friend(uuid) to authenticated;

-- ---------------------------------------------------------------------------
-- 9. GRANTs das tabelas
-- (necessario para o PostgREST acessar; a RLS continua controlando as linhas)
-- ---------------------------------------------------------------------------
grant usage on schema public to anon, authenticated, service_role;

-- Usuarios autenticados: leitura/escrita conforme as politicas de RLS acima
grant select, insert, update, delete on all tables in schema public to authenticated;

-- O service_role (Edge Functions / admin) tem acesso total
grant all on all tables in schema public to service_role;

grant select on public.ranking to authenticated, service_role;


-- ============================================================================
-- FIM. Depois de rodar, crie seus usuarios pela tela de cadastro do app.
-- Para promover um admin (para aprovar saques), rode:
--   update public.profiles set is_admin = true where username = 'seu_usuario';
-- ============================================================================
